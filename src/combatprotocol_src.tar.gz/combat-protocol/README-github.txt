Going forward, your git workflow will be:
bash# After making changes to your code:
git add .
git commit -m "Description of what you changed"
git push


